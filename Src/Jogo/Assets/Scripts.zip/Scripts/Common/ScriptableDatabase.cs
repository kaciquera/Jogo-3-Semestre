using UnityEngine;

public class ScriptableDatabase : ScriptableObject
{

}